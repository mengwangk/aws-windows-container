﻿$vs_project_location="C:\Dev\MyWebApp\MyWebApp.sln"
$ecr_repo_name="mywebapp"
$ecs_cluster_name="MyContosoCluster"
$local_release_image_name="mywebapp:latest"
$service_name="MyWebAppService"


function LogInfo {
 param( [string] $info )
 Write-Host $info;
}

function LogError {
 param( [string] $error )
 Write-Host $error -ForegroundColor Red
}
<##>
#tell powershell to stop if processing further if an error happens
$ErrorActionPreference = "Stop"

#location of your msbuild file that will build your solution 
$msbuild = "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\MSBuild\15.0\Bin\MsBuild.exe"
 
LogInfo("Step 1 : Building the web application ################################################## ");
#we will build a release version
.$msbuild $vs_project_location /t:Build /p:Configuration=Release
$buildState=$LastExitCode

if($buildState -ne 0){
    LogError("Software building step failed. Check console output for errors");
    exit 1
}


LogInfo("Step 2: Checking ECR Repsitory ################################################## ");



$repo=Get-ECRRepository | where {$_.RepositoryName -eq $ecr_repo_name}
if($repo -eq $null){
    LogInfo("There is no repository called $ecr_repo_name. Let's create a one!");
    $repo=New-ECRRepository -RepositoryName $ecr_repo_name
}

if($repo -eq $null){
    LogError("Failed to find or create a repo called $ecr_repo_name");
    Exit 1
}else{
    Write-Host "Found a repository called  $ecr_repo_name at " $repo.RepositoryUri.ToString();
}

LogInfo("Step 3: Tagging the build image with repo url ################################################## ");

$destination_full_name=$repo.RepositoryUri.ToString()+":latest"
docker tag $local_release_image_name $destination_full_name


LogInfo("Step 4: logging into repo ################################################## ");
Write-Host "Finding which region your build machine is running"
$region=(Get-EC2InstanceMetadata -Category Region).SystemName
LogInfo("Your build machine is runnin at $region")

LogInfo("Trying to login to ECR with EC2 instance credentail")
Invoke-Expression -Command (Get-ECRLoginCommand -Region $region).Command 

LogInfo("Step 5: publishing the image ################################################## ");


docker push $destination_full_name


LogInfo("Step 6: Asking ECR to refresh the service ################################################## ");


Update-ECSService -Cluster $ecs_cluster_name -Service $service_name -DesiredCount 1 -HealthCheckGracePeriodSecond 60 -DeploymentConfiguration_MinimumHealthyPercent 50 -DeploymentConfiguration_MaximumPercent 200  -ForceNewDeployment $true



